package com.example.todo12;

public class Intent {
    public Intent(Object p0, Uri url) {
    }
}
