package edu.gcit.todo_17;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import edu.gcit.todo_17.R;

public class MainActivity extends AppCompatActivity {
    private int Score1;
    private int Score2;

    private TextView ScoreText1, ScoreText2;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.night_mode){
            int nideMode = AppCompatDelegate.getDefaultNightMode();
            if (nideMode == AppCompatDelegate.MODE_NIGHT_YES) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
            else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }
        }

        return true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ScoreText1 = findViewById(R.id.score1);
        ScoreText2 = findViewById(R.id.score2);
    }

    public void decreaseScore(View view) {
        int viewID = view.getId();

        switch(viewID) {
            case R.id.decreaseTeam1:
                Score1--;
                ScoreText1.setText(String.valueOf(Score1));
                break;
            case R.id.decreaseTeam2:
                Score2--;
                ScoreText2.setText(String.valueOf(Score2));
                break;
        }
    }

    public void increaseScore(View view) {
        int viewID = view.getId();
        switch (viewID){
            case R.id.increaseTeam1:
                Score1++;
                ScoreText1.setText(String.valueOf(Score1));
                break;
            case R.id.increaseTeam2:
                Score2++;
                ScoreText2.setText(String.valueOf(Score2));
                break;
        }
    }
}