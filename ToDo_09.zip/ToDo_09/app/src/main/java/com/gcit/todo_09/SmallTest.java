package com.gcit.todo_09;

public @interface SmallTest {
}
