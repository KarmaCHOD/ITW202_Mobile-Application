package com.gcit.todo_09;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import static org.hamcrest.Matchers.closeTo;
import static org.junit.Assert.*;

import androidx.test.filters.SmallTest;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;

@RunWith(JUnit4.class)
@SmallTest
public class ExampleUnitTest {
    private Calculator calculate;
    @Before
    public void SetUp(){
        calculate = new Calculator();

    }
    //for addition
    @Test
    public void addTwoNumber(){
        double result = calculate.Add(5d,5d);
        assertThat(result, is(equalTo(10d)));
    }
    //for multiplication
    @Test
    public void MulTwoValue(){
        double result = calculate.Mul(2d,3d);
        assertThat(result,is(equalTo(6d)));

    }
    //for substration
    @Test
    public void subWorksWithNegativeResults(){
        double result = calculate.Sub(-2d,-6d);
        assertThat(result,is(equalTo(4d)));

    }
    @Test
    //multiply two numbers atleast one of two number sets to be 0
    public void mulTwoNumbersZero(){
        double result=calculate.Mul(3d,0d);
        assertThat(result,is(equalTo(0d)));
    }

    @Test
    //divide two non-zero number
    public void divTwoNumbers(){
        double result=calculate.Div(20d,5d);
        assertThat(result,is(equalTo(4d)));
    }
@Test
//testing the division with divider 0
    public void divTwoNumbersZero(){
        double result=calculate.Div(15d,0d);
        assertThat(result,is(equalTo(Double.POSITIVE_INFINITY)));
}




}