package com.example.todo_8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static String TAG=MainActivity.class.getName();
    private TextView header;
    private EditText edt1, edt2, edt3;
    private Button btn1,btn2, btn3;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt1=findViewById(R.id.edtweb);
        btn1=findViewById(R.id.button);
        edt2=findViewById(R.id.edtlocat);
        btn2=findViewById(R.id.button2);
        edt3=findViewById(R.id.edtshare);
        btn3=findViewById(R.id.button3);

    }
    public void website(View view){
        String msg=edt1.getText() .toString();
        Uri uri= Uri.parse(msg);
        Intent intent=new Intent(Intent.ACTION_VIEW,uri);
        if (intent.resolveActivity(getPackageManager())!=null){
            startActivity(intent);
        }
        else {
            Log.d(TAG, "implicit:error message");
        }

    }
    public void location(View view){
        String message=edt2.getText().toString();
        Uri uri=Uri.parse("geo:0,0?q="+message);
        Intent intent=new Intent(Intent.ACTION_VIEW, uri);
        if (intent.resolveActivity(getPackageManager())!=null){
            startActivity(intent);
        }
        else {
            Log.d(TAG, "implicit:wrong location message");
        }

    }
    public void share(View view){
        String txt=edt3.getText().toString();
        String mimeType="text/plain";
        ShareCompat.IntentBuilder
                .from(this)
                .setType(mimeType)
                .setChooserTitle("Share this with text with:")
                .setText(txt)
                .startChooser();









    }
}